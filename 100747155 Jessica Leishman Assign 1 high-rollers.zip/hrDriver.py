# Software Quality Assignment 1
# High Rollers Game

# Run this file to start the game!
import highrollers

highrollers.main_menu()